KharratCode — Windows 10 Portable
=================================

English
-------
1. Extract this ZIP completely to any writable folder.
2. Double-click KharratCode.exe.
3. The application opens in your default browser and works entirely offline.
4. Keep KharratCode.exe and KharratCode.html in the same folder.

No installation, administrator access, or internet connection is required.
The launcher only opens the bundled local HTML application. If Windows
SmartScreen warns about an unsigned application, choose "More info" and then
"Run anyway" after confirming that this ZIP came from the project repository.

فارسی
-----
۱. فایل ZIP را به‌طور کامل در یک پوشه دلخواه استخراج کنید.
۲. فایل KharratCode.exe را اجرا کنید.
۳. نرم‌افزار در مرورگر پیش‌فرض باز می‌شود و کاملاً آفلاین کار می‌کند.
۴. دو فایل KharratCode.exe و KharratCode.html را کنار یکدیگر نگه دارید.

نصب، دسترسی Administrator یا اتصال اینترنت لازم نیست. اگر SmartScreen به دلیل
امضانشدن فایل هشدار داد، پس از اطمینان از دریافت ZIP از مخزن پروژه، گزینه‌های
More info و سپس Run anyway را انتخاب کنید.
